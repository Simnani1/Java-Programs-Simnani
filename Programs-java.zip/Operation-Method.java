//Addition,Subtraction and Multiplication by method

class Ltbp{


	int a =10;
	int b =20;

	void add(){

System.out.println(a+b);

	}

void mul(){

System.out.println(a*b);

	}

	void div(){

System.out.println(a/b);

	}
public static void main(String[]args){


	Ltbp t = new Ltbp();

	t.add();
	t.mul();
	t.div();
System.out.println(t.a+t.b);
System.out.println(t.a*t.b);
System.out.println(t.b/t.a);

}
}