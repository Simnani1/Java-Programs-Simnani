//Instance Variable
//Accessing Instance variable from static area
//update value of instance variable in instance area and print them again.

 class Ltbp{

 	int a =10;
 	int b= 20;
 	int c=30;

public static void main(String[]args){

	Ltbp t = new Ltbp();

	System.out.println(t.a);
	System.out.println(t.b);
	System.out.println(t.c);

	Ltbp t1 = new Ltbp();

	t1.a=40;
	t1.b=50;
	t1.c=60;

	System.out.println(t1.a);
	System.out.println(t1.b);
	System.out.println(t1.c);

	Ltbp t2 = new Ltbp();

	t2.a=80;
	t2.b=90;
	t2.c=100;

	System.out.println(t2.a);
	System.out.println(t2.b);
	System.out.println(t2.c);


	

	

}

		
}