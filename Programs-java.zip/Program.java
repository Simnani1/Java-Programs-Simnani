class Ltbp{


	public static void main(String[]args)
	{
int [] a =new int[1];


		Ltbp t = new Ltbp();

		System.out.println(t.getClass().getName());//Get output class "Ltbp"
		System.out.println(a[0]);//If the array object reference is printed which is "a" in tis case we get class@hashcode,output-[I@7a81197d,we get [I because a is integer
		System.out.println(a);
		System.out.println(t);//Get output for object reference(t) Ltbp@5ca881b5(class-name@hashcode)
		                      //whenever we try to print the object reference internally toString() is called and it gives the output in the format class@hashcode where hashcode is hexadecimal number where object is created.

	}
}