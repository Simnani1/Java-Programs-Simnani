 //program having two instance variable a,b and two local variable a,b.print the values. 

  class Gkp{

int a;
int b;

	public static void main(String[]args){
int a=0;//Local variables must be initialized except arrays
int b=	0;



 
System.out.println(a);
System.out.println(b);


Gkp t =new Gkp(); //Need to create an object if you are accessing instance variable to static area


		
	System.out.println(t.a);
	System.out.println(t.b);			


}



		}

