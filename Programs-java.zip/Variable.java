//Declare two instance variable of int type without initialization and two static float varibles with values 20.2 and 40.2
//Print the values of all the variables and update the values of instance and static variable with the values 10,20,30,40 and again print them

class Gkp{

int a;
int b;
static float f =20.2f;
static float g=40.2f;

	public static void main(String[]args){

		System.out.println(Gkp.f);
		System.out.println(Gkp.g);

		Gkp t =new Gkp();

			System.out.println(t.a);
				System.out.println(t.b);



				t.a=10;
				t.b=20;
				Gkp.f=30;
				Gkp.g=40;



System.out.println(t.a);
		System.out.println(t.b);
    

		
			System.out.println(Gkp.f);
				System.out.println(Gkp.g);


}



		}

