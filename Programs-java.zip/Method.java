   class Ltbp{
 
int a;
int b;
static int c;
float  d;


 void m1()
{
	int a =10;
	System.out.println("This is method");
	Ltbp t = new Ltbp();
	System.out.println(t.a);//accessing instance variable from instance area to instance area
	System.out.println(a);//accessing instance variable from instance area to instance area
	System.out.println(b);//accessing instance variable from instance area to instance area
	System.out.println(Ltbp.c);//accessing static variable from instance area to instance area
	System.out.println(d);//accessing instance variable from instance area to instance area


	
	}
		
		static void m2(int a)
		{

			int b =20;
			System.out.println("This is method");
			Ltbp t = new Ltbp();
			
	System.out.println(t.a);//accessing instance variable from instance area to static area
	System.out.println(t.b);//accessing instance variable from instance area to instance area
	System.out.println(b);
	System.out.println(t.d);
	System.out.println(Ltbp.c);////accessing static variable from instance area to static area
     t.m1();//calling instance method to static area
		}

public static void main(String[]args)
{
Ltbp t = new Ltbp();


System.out.println(t.a);
	
	System.out.println(t.d);

	System.out.println(t.b);
	System.out.println(Ltbp.c);

t.m1();
Ltbp.m2(10);////calling static method to static area
}



}







				




		 


