class Ltbp{

	static {

		System.out.println("This is static block");
	}

	Ltbp(){
System.out.println("This is zero arg constructorc");

	}

	Ltbp(){
System.out.println("This is one arg constructorc");

	}

	public static void main(String[] args) {
		Ltbp t = new Ltbp();
		//Ltbp t2 = new Ltbp(10);
	}
}