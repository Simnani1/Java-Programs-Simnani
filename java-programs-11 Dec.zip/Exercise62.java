class Ltbp{
static int a=100;
int c =100;
	static{
int b=200;
		System.out.println(b);
		System.out.println(a);

		Ltbp t = new Ltbp();
		t.c=200;
		System.out.println(t.c);
	}

	public static void main(String[] args) {
		System.out.println(Ltbp.a);
	}
	}

