class Ltbp{

	static{

		System.out.println("This is static block");
	}

	static{

		System.out.println("This is second static block");
	}

	void m1(){

		Ltbp t2 = new Ltbp();
		System.out.println("This is method");
	}

	void m2(){

		Ltbp t4 = new Ltbp();
		System.out.println("This is second method");
	}

Ltbp(){
System.out.println("This is  constructor");

}
Ltbp(int a){
System.out.println("This is one arg constructor");

}
	{

		System.out.println("This is first instance block");
	}

	{

		System.out.println("This is second instance block");
	}

	public static void main(String[] args) {
		Ltbp t = new Ltbp();
		Ltbp t1 = new Ltbp(10);
		Ltbp t3 =  new Ltbp();
		t3.m1();
		Ltbp t5 = new Ltbp();
		t5.m2();
	}
} 