class Ltbp{

	static{

		System.out.println("This is static block");
	}

	static{

		System.out.println("This is second static block");
	}

	{

		System.out.println("This is first instance block");
	}

	{

		System.out.println("This is second instance block");
	}

	public static void main(String[] args) {
		Ltbp t = new Ltbp();
		Ltbp t1 = new Ltbp();
	}
} 