class Ltbp{
static int a;
int b;
int c;
int d;
	static{
int e=5000;
		a=100;
Ltbp t = new Ltbp();

		System.out.println(a);
		System.out.println(e);
		System.out.println(t.b);
		System.out.println(t.c);
		System.out.println(t.d);
	}

	

	{
		int e=500;
b=200;
System.out.println(Ltbp.a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);

	}

	Ltbp(){
int e =500;
		c=300;
		System.out.println(Ltbp.a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
	}

	void m1(){
int e=500;
		d =400;
		System.out.println(Ltbp.a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);

	}

	public static void main(String[] args) {
System.out.println(Ltbp.a);
		Ltbp t = new Ltbp();
		System.out.println(t.b);
		System.out.println(t.c);
		System.out.println(t.d);
		t.m1();
	}
}