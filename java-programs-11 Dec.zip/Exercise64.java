class Ltbp{

	static{

		System.out.println("This is static block");
	}

	static{

		System.out.println("This is second static block");
	}

	public static void main(String[] args) {
		
	}
}