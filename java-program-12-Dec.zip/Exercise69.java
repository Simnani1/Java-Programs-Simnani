 class Ltbp{

 	Ltbp(){
 		this(10);
System.out.println("This is zero arg constructor" );

 	}

 	Ltbp(int a){
System.out.println("This is one arg constructor" );

 	}
 	public static void main(String[] args) {
 			Ltbp t = new Ltbp();

 	}
 }