 class Ltbp{

 	Ltbp(){
 		
System.out.println("This is zero arg constructor" );

 	}

 	Ltbp(int a){
 		
 		Ltbp t = new Ltbp();//->This statement does not need to be first statement like this()
System.out.println("This is one arg constructor" );

 	}
 	public static void main(String[] args) {
 			Ltbp t = new Ltbp(10);

 	}
 }