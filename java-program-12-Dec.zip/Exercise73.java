 class Ltbp{

 	Ltbp(){
 		
System.out.println("This is zero arg constructor" );

 	}

 	Ltbp(int a){
 		
 		Ltbp t = new Ltbp();//->This statement doest not need to be first statement like this()
System.out.println("This is one arg constructor" );

 	}

 	void m1(){

 		//this(10);->Not allowed
 		Ltbp t = new Ltbp();
 	}
 	public static void main(String[] args) {
 			Ltbp t = new Ltbp(10);
 			t.m1();

 	}
 }