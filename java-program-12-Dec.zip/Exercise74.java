 class Ltbp{
int a=10;
 	Ltbp(int a, int b){
 		

System.out.println("This is two arg constructor" );
System.out.println(this.a);

 	}

 	Ltbp(float b){
 		this(20,20);
 		
System.out.println("one arg constructor" );
System.out.println(this.a);
Ltbp t = new Ltbp(10,20);
 	}

 	{

 		System.out.println("instance block" );
 		System.out.println(a );
 	}
 	public static void main(String[] args) {
 			Ltbp t = new Ltbp(10.2f);
 			
System.out.println(t.a);
 	}
 }