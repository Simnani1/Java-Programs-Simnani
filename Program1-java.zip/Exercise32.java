class Cust{

int total=0;
int deposit;
int withdraw;



void deposit(int total, int deposit){

	this.total = total + deposit;
	System.out.println(this.total);
}
	void withdraw(int total, int withdraw){

	this.total = total - withdraw;
	System.out.println(this.total);
}
	public static void main(String[] args) {
		Cust c1 = new Cust();
		c1.deposit(0,200);

		Cust c2 = new Cust();
		c2.deposit(0,100);
	}
}