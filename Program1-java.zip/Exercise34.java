class Ltbp{

	Ltbp m1(int a, Ltbp[]...t){

		System.out.println("Hello");
		return this;
	}
	public static void main(String[] args) {
		

		
		//new Ltbp().m1(10);
		//new Ltbp().m1(10,new Ltbp [] {});
		//new Ltbp().m1(10,new Ltbp [] {new Ltbp()});
		//new Ltbp().m1(10,new Ltbp [] {new Ltbp(),new Ltbp()});
		//new Ltbp().m1(10,new Ltbp [],new Ltbp(){}, new Ltbp(){} );-confusion

		Ltbp[] t1 ={};
		Ltbp[] t2 ={};

		new Ltbp().m1(10,t1,t2);
		
		
		
		
	}
} 