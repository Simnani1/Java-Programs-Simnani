//getter and setter method

class Bank{
private int balance =0;
void setBalance(int balance) 
	{

		this.balance=balance;
	}

	int getBalance(){

		return balance;
		 
	}
	
		public static void main(String[] args){
			
			

			Bank b = new Bank();
			b.setBalance(0);
			System.out.println(b.getBalance());
			
			
			
			

			
		}
	}
