class Ltbp{

	void m1(int ...a){

		System.out.println("m1 var arg");
	}

	int m1(float b,int ...a){

		System.out.println("m1 with float");
		return 0;
	}

	public static void main(String ...args) {
		//new Ltbp().m1();
		//new Ltbp().m1(12.2f);
		new Ltbp().m1(12.2f,10);
	}
}
 
