//operator overloading is not allowed in jva

//+ operator overloading

class Ltbp{

int a= 10;

int b=20;


public static void main(String[] args) {
	Ltbp t = new Ltbp();
	System.out.println(t.a + t.b);
	System.out.println(t.a + " " + t.b);
}
}