class Ltbp {

	int a =100;
	int b;

	int m1(int b){
this.b=b;
		//b=this.b;
return 10;

	}

	Ltbp(int b){
this.b=b;

	}

	{

	this.b=500;	
	}
public static void main(String[] args) {
	Ltbp t = new Ltbp(100);
	t.m1(400);
	System.out.println(t.b);
	System.out.println(t.a);

	}
}


