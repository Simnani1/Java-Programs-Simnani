class Ltbp{
int a;
int b;
	Ltbp(){
a=10;
b=20;
System.out.println("this is constructor");
System.out.println(a);
		System.out.println(b);
	}

	Ltbp(int c){

		a=30;
		b=40;
		System.out.println("this is one arg constructor");
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}

	public static void main(String[] args) {
		System.out.println("this is main");

		Ltbp t = new Ltbp();
		System.out.println(t.a);
		System.out.println(t.b);
		Ltbp t1 = new Ltbp(100);
		System.out.println(t.a);
		System.out.println(t.b);
		System.out.println(t1.a);
		System.out.println(t1.b);
	}
}