class Ltbp{

	int[]a={10,20,30,40};
	static int b=10;
	
Ltbp m1(int[]a, Ltbp t){
System.out.println("This is m1");
System.out.println(a[0]);
System.out.println(a[1]);
System.out.println(this.a[0]);
System.out.println(this.a[1]);
System.out.println(this.a[2]);
System.out.println(this.a[3]);

System.out.println(Ltbp.b);
return this;
//return new Ltbp();



}
public static void main(String[] args) {
	//Ltbp t = new Ltbp();
	//int []b={10,20,30};
	new Ltbp().m1(new int[] {60,70},new Ltbp());
}
	}
