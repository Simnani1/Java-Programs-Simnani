//method overloading

class Ltbp{
void m1(){

	System.out.println("hii");
}

void m1(int a){

	System.out.println("hye");
}

void m1(float b){

	System.out.println("bye");
}


public static void main(String[] args) {
	Ltbp t = new Ltbp();
	t.m1();
	t.m1(10);
	t.m1(4.5f);


}
}