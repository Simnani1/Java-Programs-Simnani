//Example of instance block

class Ltbp {
{
	System.out.println("This is instance Block");


		
	}

	Ltbp(int a){
System.out.println("This is int Constructor");

	}
	Ltbp(float a){
System.out.println("This is float Constructor");

	}
public static void main(String[] args) {
	Ltbp t = new Ltbp(10);
	Ltbp t1 = new Ltbp(10.2f);

	}
}


