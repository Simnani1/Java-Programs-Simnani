class Emp{


int eid;
String name;
float esal;
int age;

static String org_name="Ltbp";

Emp(int eid,String name, float esal,int age){
this.eid=eid;
this.name=name;
this.esal=esal;
this.age=age;



}
void display(){

	System.out.println(eid);
	System.out.println(name);
	System.out.println(esal);
	System.out.println(age);
	System.out.println(Emp.org_name);
}
	public static void main(String[] args) {
		Emp e1=new Emp(1,"anush",5122.5f,30);
		e1.display();
		Emp e2=new Emp(2,"rajiv",4122.5f,20);
		e2.display();
	}
}