class Ltbp {

	

	static int a=10;
	int b=100;

	Ltbp(int c){

		b=c;
		System.out.println(b);
		System.out.println(Ltbp.a);
	}

	void m1(int b){

		this.b=b;
		System.out.println(this.
			b);
		System.out.println(b);
		System.out.println(Ltbp.a);
	}

	static void m2(int b){
Ltbp t= new Ltbp(10);
t.b=b;
System.out.println(Ltbp.a);
		System.out.println(b);

	}

	{

		b=100;
		Ltbp.a=200;
		System.out.println(b);
		System.out.println(Ltbp.a);
	}
public static void main(String[] args) {
	Ltbp t = new Ltbp(100);
	t.m1(500);
	System.out.println(Ltbp.a);
	System.out.println(t.b);

	}
}


