

class Ltbp{

	int a;
	static int b=20;
	Ltbp(int a){
System.out.println (a);

		System.out.println(this.a);
		System.out.println(Ltbp.b);
		
		
	}
Ltbp(int[]... a){

		
		System.out.println(a[0][0]);
		System.out.println(a[0][1]);
		System.out.println(a[0]
			  [2]);
		
System.out.println(this.a);
		System.out.println(Ltbp.b); 
}

Ltbp m1(int a, int b){


System.out.println(a);
		System.out.println(b);
		System.out.println(this.a);
		System.out.println(Ltbp.b);
		
		return this;
}


public static void main(String[] args) {
	new Ltbp(10).m1(20,30);
	int [] a ={10,20,30};
	new Ltbp(a);
}
} 