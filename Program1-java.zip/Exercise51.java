//constructor  overloading

class Ltbp{
Ltbp(){

	System.out.println("hii");
}

Ltbp(int a){

	System.out.println("hye");
}

Ltbp(float b){

	System.out.println("bye");
}


public static void main(String[] args) {
	Ltbp t1 = new Ltbp();
	Ltbp t2 = new Ltbp(10);
	Ltbp t3 = new Ltbp(6.7f);
	


}
}