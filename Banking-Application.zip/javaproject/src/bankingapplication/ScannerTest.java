package bankingapplication;
import java.util.*;

public class ScannerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s = new Scanner(System.in);
System.out.println("Enter a character");
//int a =s.nextInt();
char c =s.next().charAt(0);
System.out.println("value = " + c);
	}

}
