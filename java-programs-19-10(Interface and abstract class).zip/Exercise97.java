interface I1{

	int a=10;
	void m1();
	void m2();
}

interface I2{

	void m3();
	void m4();

}

class A implements I{

	public void m1(){

		System.out.println("This is m1" );
	}

	public void m2(){
System.out.println("This is m2" );

	}
	public void m3(){
System.out.println("This is m3" );

	}
	public void m4(){
System.out.println("This is m4" );

	}


public static void main(String[] args) {
	A a = new A();
	a.m1();
	a.m2();
	a.m3();
	a.m4();
	System.out.println(a.a);
}
}