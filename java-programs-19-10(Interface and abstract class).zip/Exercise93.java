abstract class Ltbp{

	abstract void m1();
	abstract int m2(int a);
	abstract float m3(String s);
}

abstract class Bit extends Ltbp{

	void m1(){

		System.out.println("This is m1" );//implementation of abstract method
	}

	int m2(int a)
	{

		System.out.println("This is m2" );
		return 10;
	}
	



}

abstract class ABC extends Bit{

	abstract int m2(int a);

	float m3(String s){
System.out.println("This is m3" );
		return 10.2f;

	}
}

class Gkp extends ABC{

	 int m2(int a){
System.out.println("This is m2" );
return 10;

	}


	public static void main(String[] args) {
		Gkp g = new Gkp();
		
		g.m1();
		g.m2(10);
		g.m3("LTBP");
	}
}