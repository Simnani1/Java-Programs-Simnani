interface I1{

	int a=10;
	void m1();
	void m2();
}



class A implements I1{

	public void m1(){

		System.out.println("This is m1" );
	}

	public void m2(){
System.out.println("This is m2" );

	}
	

public static void main(String[] args) {
	I1 i = new A();
	i.m1();
	i.m2();
	System.out.println(i.a);
	//System.out.println(I1.a);
}
}