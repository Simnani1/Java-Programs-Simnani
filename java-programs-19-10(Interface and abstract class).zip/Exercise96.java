//interface

interface I{

	int a=10;
	void m1();
	void m2();
}

class A implements I{

	public void m1(){

		System.out.println("This is m1" );
	}

	public void m2(){
System.out.println("This is m2" );

	}


public static void main(String[] args) {
	A a = new A();
	a.m1();
	a.m2();
	System.out.println(a.a);
}
}