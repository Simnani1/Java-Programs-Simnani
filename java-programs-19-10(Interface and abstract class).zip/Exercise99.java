interface I1{

	int a=10;
	void m1();
	void m2();
}

interface I2{

	void m3();
	int a=100;
}

abstract class Ltbp{

	int b=200;
	abstract void m4();
}


class A extends Ltbp implements I1,I2{

	public void m1(){

		System.out.println("This is m1" );
	}

	public void m2(){
System.out.println("This is m2" );

	}
	
	public void m3(){
System.out.println("This is m3" );

	}

void m4(){
System.out.println("This is m4" );
		
	}

public static void main(String[] args) {
	A a = new A();
	a.m1();
	a.m2();
	a.m3();
	a.m4();
	
	System.out.println(I1.a);
	System.out.println(I2.a);
	System.out.println(a.b);
}
}