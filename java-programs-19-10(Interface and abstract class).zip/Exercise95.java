abstract class Ltbp{

	abstract void m1();
	abstract int m2(int a);
	abstract float m3(String s);
	abstract int m4(int b);
}

abstract class Bit extends Ltbp{

	void m1(){

		System.out.println("This is m1" );
	}
}

abstract class Kipm extends Bit{

	int m2(int a)
	{

		System.out.println("This is m2" );
		return 10;
	}
}

abstract class Itm extends Kipm{

	float m3(String s)
	{

		System.out.println("This is m3" );
		return 10.2f;
	}


}

 class Integ extends Itm{
int m4(int b)
	{

		System.out.println("This is m4" );
		return 20;
	}

}

class Luckn{

	public static void main(String[] args) {
		Integ t = new Integ();
		t.m1();
		t.m2(21);
		t.m3("Ltbp");
		t.m4(22);
	}
}