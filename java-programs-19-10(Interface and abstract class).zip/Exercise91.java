//abstract class

abstract class Ltbp{

	abstract void m1();
	abstract int m2(int a);
	abstract float m3(String s);
}

class Bit extends Ltbp{

	void m1(){

		System.out.println("This is m1" );
	}

	int m2(int a)
	{

		System.out.println("This is m2" );
		return 10;
	}
	float m3(String s)
	{

		System.out.println("This is m3" );
		return 10.2f;
	}



}

class Gkp{

	public static void main(String[] args) {
		Bit b = new Bit();
		b.m1();
		b.m2(10);
		b.m3("LTBP");
	}
}